my_list = ["One", "piece", "per", "time"]

for item in my_list:
    print(item)