my_set = set([1, 2, 3, 2])
print(my_set)

# Відображення: {1, 2, 3}

# my_set1 = {1, 2, [3, 4]}
# print(my_set1)
#
# Traceback (most recent call last):
#   File "<string>", line 15, in <module>
#     my_set = {1, 2, [3, 4]}
# TypeError: unhashable type: 'list'
