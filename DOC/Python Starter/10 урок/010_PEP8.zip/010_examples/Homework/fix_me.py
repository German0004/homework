import math, random
from math import pi
from math import e
print=5
СoUnt = int ( input ( ' Введите количество повторов : ' ) )
print ( print*СoUnt )
print ( pi*print*СoUnt )
print ( e*2 )
while     print>=0     :
        print-=1
str='my string'
sum=0
for     elem    in  str  :
        sum+=pow(str.find(elem),2)
            print ("sum=",sum)
def  MY_FUNC  (atr = 1)    :
        print ( ' atr',atr )
print ( MY_FUNC ( atr = 5 ) )