__all__ = ['a']

a = 10
b = 20
c = 5.4


def my_average():
    pass
