def function():
    print(var)  # отримання доступу до глобальної змінної


var = 'глобальна змінна'
function()
