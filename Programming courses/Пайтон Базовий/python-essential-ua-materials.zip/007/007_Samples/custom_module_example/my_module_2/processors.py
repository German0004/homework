class Processor:
    def __init__(self):
        pass

    def process(self):
        print('Process')
