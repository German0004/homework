﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using PostApp.Model;

namespace PostApp.Data
{
    public class PostContext
    {
        private IMongoDatabase Database { get; }
        
        public PostContext(IConfiguration configuration)
        {
            var url = new MongoUrl(configuration.GetConnectionString("MongoConnection"));
            var client = new MongoClient(url);
            Database = client.GetDatabase(url.DatabaseName);
        }

        public IMongoCollection<Post> Posts => Database.GetCollection<Post>("Post");

    }
}
