# example_1.py

class Person:
    def _get_secret(self):
        print("It is my big secret!")


me = Person()
me._get_secret()
