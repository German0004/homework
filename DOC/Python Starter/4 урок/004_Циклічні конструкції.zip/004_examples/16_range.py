my_range1 = range(3)
my_range2 = range(5)

test1 = 3 in my_range1
test2 = 3 in my_range2
print(test1)
print(test2)
