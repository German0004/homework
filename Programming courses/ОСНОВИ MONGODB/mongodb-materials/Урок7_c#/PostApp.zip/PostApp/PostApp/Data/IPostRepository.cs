﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Driver;
using PostApp.Model;

namespace PostApp.Data
{
    public interface IPostRepository
    {
        Task<IEnumerable<Post>> GetAllPosts();
        Task<Post> GetPost(string id);
        Task AddPost(Post item);
        Task<DeleteResult> RemovePost(string id);
        Task<UpdateResult> UpdatePost(string id, string text);
    }
}
