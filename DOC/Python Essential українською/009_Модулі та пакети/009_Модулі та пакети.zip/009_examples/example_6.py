from math import sin, cos, tan, atan

print(sin(1))
print(cos(1))
print(tan(1))
print(atan(1))
