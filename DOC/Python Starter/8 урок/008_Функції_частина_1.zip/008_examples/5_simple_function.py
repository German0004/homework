def add_numbers(a, b):
    return a + b  # повернення суми параметрів


x = add_numbers(2, 3)
print(x)
