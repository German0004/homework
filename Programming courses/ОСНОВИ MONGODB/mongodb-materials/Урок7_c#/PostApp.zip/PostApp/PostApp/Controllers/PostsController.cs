﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PostApp.Data;
using PostApp.Model;

namespace PostApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostsController : ControllerBase
    {
        private IPostRepository PostRepository { get; }

        public PostsController(IPostRepository postRepository)
        {
            PostRepository = postRepository;
        }

        // GET: api/Posts
        [HttpGet]
        public async Task<IEnumerable<Post>> Get()
        {
            return await PostRepository.GetAllPosts();
        }

        // GET: api/Posts/5
        [HttpGet("{id}", Name = "Get")]
        public async Task<Post> Get(string id)
        {
            return await PostRepository.GetPost(id);
        }

        // POST: api/Posts
        [HttpPost]
        public void Post([FromBody] Post newPost)
        {
            PostRepository.AddPost(newPost);
        }

        // PUT: api/Posts/5
        [HttpPut("{id}")]
        public void Put(string id, [FromBody] string value)
        {
            PostRepository.UpdatePost(id, value);
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(string id)
        {
            PostRepository.RemovePost(id);
        }


    }
}
