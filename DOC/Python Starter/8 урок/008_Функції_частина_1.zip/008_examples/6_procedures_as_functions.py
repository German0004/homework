def procedure():
    print('I return nothing... Or I do?')


value = procedure()
print('Результат функції:', value)
