string = input("Введіть рядок: ")

if string is not None and string != '':
    num = int(string)

if string:
    num = int(string)

print(num)
