//alert("Hello world from file1.js");
while(true) {
    
}