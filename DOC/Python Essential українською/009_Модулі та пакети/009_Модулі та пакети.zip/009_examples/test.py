import geom

var = geom.r
print(var)
