# імпротуємо модуль math
import math

x = 3.265
# ціле число, найближче ціле знизу, найближче ціле зверху
print(math.trunc(x), math.floor(x), math.ceil(x))
print(math.cos(60))

# константа пі
print(math.pi)
# число Ейлера
print(math.e)

# math.sin – синус
y = math.sin(math.pi / 4)
print(round(y, 2))

# math.sqrt – квадратний корінь
y = 1 / math.sqrt(2)
print(round(y, 2))
