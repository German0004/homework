a = 5
b = 10

a += b  # a = a + b = 5 + 10 = 15
print(a)
a -= b  # a = a - b = 5 - 10 = -5
print(a)
a *= b  # a = a * b = 5 * 10 = 50
print(a)
a /= b  # a = a / b = 5 / 10 = 0.5
print(a)
