d = {1: 1, 2: 2, 3: 3, 4: 4, 5: 5}
for number, number_val in d.items():
    if number % 2 == 0:
        print(number, number_val)
