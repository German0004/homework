# Створимо змінну name (змінні докладно # розглядаються у наступному уроці)
# Змінній name ми присвоюємо значення 'Alex'
name = "Alex"
age = 14
info = 'Qwerty'
print(type(info))

# Після цього можна звертатися до цього значення на ім'я
print(name)
print(age)
print(info)
info = 15
print(type(info))
print(info)
