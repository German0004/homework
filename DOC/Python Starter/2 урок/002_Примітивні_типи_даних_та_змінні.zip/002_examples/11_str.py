# Приклади рядків
s1 = "Строка 1"
s2 = 'Строка 2'
print(s1, s2)

# Конструювання рядка з іншого значення
s3 = str(8)
print(s3)
print(type(s3))

# Багаторядкові рядки
s4 = """
Lesson 2. Variables and Data Types
Some data types explained in this lesson:
 - int
 - bool
 - float
 - complex
 - str
"""
print(s4)

# \ використовується, щоб продовжити рядок або будь-який вираз у Python з наступного рядка коду
s5 = "started\
        continued"
print(s5)
