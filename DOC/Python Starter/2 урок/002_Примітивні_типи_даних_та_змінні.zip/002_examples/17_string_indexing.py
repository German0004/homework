# Створення рядка
string = "a string"

# Виведення окремих символів рядка
print(string[0])  # 'a'
print(string[6])  # 'n'
print(string[-2])  # 'n'
print(string[-1])  # 'g'
