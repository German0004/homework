class MyClass:
    """
    Some text
    """
    my_field = 1
    my_field2 = 2

    def __init__(self):
        self.a = "1"


print(MyClass.__dict__)
