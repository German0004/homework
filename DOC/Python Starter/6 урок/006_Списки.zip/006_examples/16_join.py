char_list = ["a", "e", "i", "o", "u", "y"]
str_list = "; ".join(char_list)
print("Рядок голосних:", str_list)
