my_digit = 14
# TypeError: argument of type 'int' is not iterable
# print(4 in my_digit)

my_string = 'test'
print('e' in my_string)

my_tuple = 10, 12, 14
print(12 in my_tuple)

my_list = [10, 12, 14]
print(12 in my_list)

