print(eval("1024 * 4"))
print(eval("sum([8.5, 6, 12.5])"))
