__all__ = ['h']

d = [1, 3, 5]
h = 'Hello!'
