# правильное подключение нескольких функций модуля
from math import cos, sin

print(cos(45) + sin(75))
