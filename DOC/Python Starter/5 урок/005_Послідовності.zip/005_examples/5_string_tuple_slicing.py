# Створення рядка
string = "a string"

# Виведення зрізів рядка
print(string[2:5])  # str
print(string[:5])  # a str
print(string[2:])  # string
print(string[::2])  # asrn

# Отримання окремих елементів рядка та їх конкатенація
print(string[2] + string[-3:])  # sing

my_tuple = 1, 0, 31
print(my_tuple[:1] + my_tuple[1:])


