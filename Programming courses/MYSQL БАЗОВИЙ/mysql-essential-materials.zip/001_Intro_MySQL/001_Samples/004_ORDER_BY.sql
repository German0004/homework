USE carsShop;


SELECT * FROM carsshop.cars;




SELECT * FROM carsshop.cars ORDER BY mark;  -- Óïîðÿäî÷èòü ïî èìåíè.


SELECT * FROM carsshop.cars ORDER BY model;  -- Ñîðòèðîâàòü ïî ModifiedDate


SELECT * FROM carsshop.cars ORDER BY mark, model;  


SELECT * FROM carsshop.cars ORDER BY speed ASC; 


SELECT * FROM carsshop.cars ORDER BY speed DESC; 

