# Істинне значення
boolean_1 = True

# Хибне значение
boolean_2 = False

print(boolean_1)
print(boolean_2)
