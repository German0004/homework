﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Driver;
using PostApp.Model;

namespace PostApp.Data
{
    public class PostRepository : IPostRepository
    {
        private PostContext Context { get; }

        public PostRepository(PostContext context)
        {
            Context = context;
        }

        public async Task<IEnumerable<Post>> GetAllPosts()
        {
            return await Context.Posts.Find(x=>true).ToListAsync();
        }

        public async Task<Post> GetPost(string id)
        {
            var filter = Builders<Post>.Filter.Eq("Id", id);
            return await Context.Posts.Find(filter).FirstOrDefaultAsync();
        }

        public async Task AddPost(Post item)
        {
            await Context.Posts.InsertOneAsync(item);
        }

        public async Task<DeleteResult> RemovePost(string id)
        {
            var filter = Builders<Post>.Filter.Eq("Id", id);
            return await Context.Posts.DeleteOneAsync(filter);
        }

        public async Task<UpdateResult> UpdatePost(string id, string text)
        {
            var filter = Builders<Post>.Filter.Eq("Id", id);
            var update = Builders<Post>.Update.Set(p => p.Text, text).CurrentDate(p => p.Date);
            return await Context.Posts.UpdateOneAsync(filter, update);
        }
    }
}
