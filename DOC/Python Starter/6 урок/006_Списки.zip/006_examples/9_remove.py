my_list = [32, 132, 5, 35, 51]

# Видалення елемента зі значенням 35:
my_list.remove(35)
# Помилка при видаленні елемента зі значенням 3 (ValueError: list.remove(x): x not in list):
# my_list.remove(3)

print('Список чисел:', my_list)
