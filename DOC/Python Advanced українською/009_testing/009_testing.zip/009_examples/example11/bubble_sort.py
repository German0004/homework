def my_sort(data: list) -> list:
    return sorted(data)
