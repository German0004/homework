# Створення кортежу
my_tuple = (1, 2, 3)

print(my_tuple)
# Адресація елементів
# 1
print(my_tuple[0])
# 3
print(my_tuple[2])
# 3
print(my_tuple[-1])
# (2, 3)
print(my_tuple[1:3])
# IndexError
# print(my_tuple[10])
print('Length:', len(my_tuple))
