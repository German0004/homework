import test

r = 234
print(test.var)
