# Вкладеність усередині пакету:
from .. my_module1 import a

