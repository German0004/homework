# Визначення функції hello_world
def hello_world():
    print('Hello, World!')


# Виклик функції hello_world
hello_world()
print()

# Виклик функції hello_world 15 разів
for i in range(15):
    hello_world()
