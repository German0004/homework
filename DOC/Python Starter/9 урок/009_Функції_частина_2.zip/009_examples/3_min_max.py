a = 5
b = 7
c = 2

# мінімальне значення
print(min(a, b, c))
# максимальне значення
print(max(a, b, c))
