x = 0

while x < 10:
    x += 1

    if x == 5:  # пропускаємо число 5
        continue

    print('Поточне число дорівнює', x)
