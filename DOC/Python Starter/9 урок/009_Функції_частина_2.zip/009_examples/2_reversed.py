# reversed дозволяє перебирати послідовність у зворотному порядку:
for i in reversed(range(5)):
    print(i)
