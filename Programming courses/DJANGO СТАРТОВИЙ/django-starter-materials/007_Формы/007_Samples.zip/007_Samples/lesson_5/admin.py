from django.contrib import admin
from lesson_5.models import *

admin.site.register(Client)
admin.site.register(Flower)
admin.site.register(Bouquet)
