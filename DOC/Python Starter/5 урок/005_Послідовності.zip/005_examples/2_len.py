my_tuple = (1, 2, 3)

print('Length:', len(my_tuple))
print('Length:', my_tuple.__len__())
