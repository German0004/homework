# i набуває значення в діапазоні [0, 10)
for i in range(10):
    print('i =', i)
