# импорты стандартной библиотеки
# импорты сторонних библиотек
# импорты модулей текущего проекта

# неправильное подключение модулей
# import math, random
# неправильно:
import os, sys
# правильное подключение модулей:
import os
import sys


var1 = os.name
print(var1)
var2 = sys.api_version
print(var2)
