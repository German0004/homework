def adder(x, y, z):
    print("sum:", x + y + z)


adder(10, 12, 13)
# TypeError: adder() takes 3 positional arguments but 5 were given.
# adder(5, 10, 15, 20, 25)
