# import all names from the standard module math

from math import *

print("The value of pi is", pi)
