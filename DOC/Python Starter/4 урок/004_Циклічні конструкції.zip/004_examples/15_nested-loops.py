for i in range(10):
    for j in range(30):
        print('*', end='')
    print()
