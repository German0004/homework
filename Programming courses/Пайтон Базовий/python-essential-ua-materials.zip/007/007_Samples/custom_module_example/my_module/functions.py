def my_function():
    print('Hello world')
