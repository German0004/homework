import unittest
from bubble_sort import my_sort


class BubbleSortTest(unittest.TestCase):
    def test(self):
        self.assertEqual(my_sort([3, 1, 5, 0, 7, 4, 10, 8])[::-1], list(reversed([0, 1, 3, 4, 5, 7, 8, 10])))
