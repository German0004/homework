from .constants import E, PI


def too_long_foo_function(value):
    return value * E


def too_long_bar_function(value):
    return value + PI ** 2
