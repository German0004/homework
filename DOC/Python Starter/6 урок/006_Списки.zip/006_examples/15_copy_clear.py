my_list = [5, 7, 1, 5, 8, 7, 1, 0, 7, -23, 15]

# Копіювання списку – метод copy()
my_list1 = my_list.copy()
print(my_list1)

# Очищаємо список my_list
my_list.clear()
print('Зміст списку my_list =', my_list)
print('Зміст списку my_list1 = ', my_list1)
