long_variable1 = 1
long_variable2 = 1
long_variable3 = 1
long_variable4 = 1
long_variable5 = 1
long_variable6 = 1

income1 = (long_variable1 + long_variable2 + (long_variable3 - long_variable4) - long_variable5 - long_variable6)

income2 = (long_variable1 +
           long_variable2 +
           (long_variable3 - long_variable4) -
           long_variable5 -
           long_variable6)

income3 = (long_variable1
           + long_variable2
           + (long_variable3 - long_variable4)
           - long_variable5
           - long_variable6)
