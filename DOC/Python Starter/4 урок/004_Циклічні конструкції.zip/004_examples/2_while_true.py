print('Усі натуральні числа:')

n = 1

while True:  # нескінченний цикл
    print(n)
    n += 1
