# Приклад модуля на Python example

def add(a, b):
    result = a + b
    return result
