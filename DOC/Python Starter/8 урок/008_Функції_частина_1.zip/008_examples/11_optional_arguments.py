# Якщо параметр name не заданий, name = 'Alex'
def hello(name='Alex'):
    print('Hello, ', name, '!', sep='')


hello('Python')
hello()
