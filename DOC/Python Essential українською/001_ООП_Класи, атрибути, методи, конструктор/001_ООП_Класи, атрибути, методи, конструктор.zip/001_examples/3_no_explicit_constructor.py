class MyClass:
    """Клас без визначення конструктора"""
    pass


# Конструктор SuperClass викликається для ініціалізації екземпляру класу
c = MyClass()
print(type(c))
