# простий приклад
while True:
    print('Введіть exit, щоб завершити цикл')
    response = input('> ')
    if response == 'exit':
        break
