with open("test.txt", 'r', encoding='utf-8') as f:
    print(f.read(7))
    print(f.read(15))
    print(f.read(10))
