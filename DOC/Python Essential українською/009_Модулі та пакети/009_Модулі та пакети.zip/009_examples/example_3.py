import math

print("The value of pi is", math.pi)

# > The value of pi is 3.141592653589793
