my_set = {1, 2, 3}
print(my_set)
# {1, 2, 3}

my_set = {1.0, "Hello", (1, 2, 3)}
print(my_set)
# {1.0, (1, 2, 3), 'Hello'}
# my_set = {1, 2, [3, 4, 5]}
# print(my_set)
my_var = {1}
print(my_var)
my_var = set()
print(my_var)
