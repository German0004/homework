from mypackage.utils.core.physics.constants import E, PI


# from .constants import E, PI


def foo(value):
    return value * E


def bar(value):
    return value + PI ** 2
